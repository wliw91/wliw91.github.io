vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|06 Nov 2018 22:00:00 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|06 Nov 2018 22:00:00 -0000
vti_filesize:IR|1253
vti_backlinkinfo:VX|
